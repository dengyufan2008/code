#include <bits/stdc++.h>
using namespace std;
#define N 10000005
int n, m, a[N], b[N];
unsigned seed;
unsigned rnd() {seed ^= seed << 13, seed ^= seed >> 17, seed ^= seed << 5; return seed;}
int rand(int l, int r) {return rnd() % (r - l + 1) + l;}
int main() {
  freopen("happy.in", "r", stdin);
  freopen("happy.out", "w", stdout);
  cin >> n >> m >> seed;
  for(int i = 1; i <= n; ++i) a[i] = 1, b[i] = rand(1, m);
  for(int i = 1; i <= n - 2; ++i) ++a[rand(1, n)];
}