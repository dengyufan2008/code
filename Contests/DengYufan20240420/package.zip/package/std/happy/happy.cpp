#include <bits/stdc++.h>
#define il inline
#define re register
#define ll long long
#define pii pair<int, int>
#define fi first
#define se second
#define eb emplace_back
using namespace std;
#define N 10000005
int n, m;
unsigned seed;
struct node {
  int d, w;
} a[N];
il unsigned rnd() {seed ^= seed << 13, seed ^= seed >> 17, seed ^= seed << 5; return seed;}
il int rand(int l, int r) {return rnd() % (r - l + 1) + l;}
int p[N], q[N];
int main() {
  freopen("happy.in", "r", stdin);
  freopen("happy.out", "w", stdout);
  ios::sync_with_stdio(0);
  cin.tie(0), cout.tie(0);
  cin >> n >> m >> seed;
  for(int i = 1; i <= n; ++i) a[i].d = 1, a[i].w = rand(1, m);
  for(int i = 1; i <= n - 2; ++i) ++a[rand(1, n)].d;
  sort(a + 1, a + 1 + n, [](node A, node B) {return A.w > B.w;});
  ll ans = 0; int pl = 1, pr = 0, ql = 1, qr = 0;
  for(re int i = 1; i <= n; ++i) {
    if(pl > pr) while(a[i].d--) p[++pr] = a[i].w;
    else {
      ans += 1ll * p[pl++] * a[i].w;
      while(--a[i].d) p[++pr] = a[i].w;
    }
    while(pl < pr && ql <= qr) ans += 1ll * p[pl++] * q[ql++];
    if(pl == pr) q[++qr] = p[pl++];
  }
  ans += 1ll * q[ql] * q[qr];
  cout << ans;
}