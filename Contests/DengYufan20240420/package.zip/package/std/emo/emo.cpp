#include<bits/stdc++.h>
#define il inline
#define re register
#define ll long long
#define ui unsigned int
#define pii pair<int, int>
#define fi first
#define se second
#define eb emplace_back
using namespace std;
#define N 32
#define M 100
int P;
il void addr(int &x, int y) {(x += y) >= P && (x -= P);}
int n; ll m; ui to[N];
map<ui, int> mp; int T; ui rev[M];
int f[M], g[M], mat[M][M], tmp[M][M];
il int dfs(ui u) {
  if(mp[u]) return mp[u]; int x = mp[u] = ++T; rev[T] = u;
  for(re int H = 0; H < 1 << n; ++H) {
    ui v = 0;
    for(re int S = 0; S < 1 << n; ++S)
      if((u >> S & 1) && (S & H) == S) v |= to[H ^ S];
    if(v) ++mat[x][dfs(v)];
  }
  return x;
}
int main() {
  freopen("emo.in", "r", stdin);
  freopen("emo.out", "w", stdout);
  ios::sync_with_stdio(0);
  cin.tie(0), cout.tie(0);
  cin >> n >> m >> P;
  for(re int S = 0; S < 1 << n; ++S) {
    to[S] = 1u << S;
    for(re int i = 0; i + 1 < n; ++i)
      if((S >> i & 1) && (S >> (i + 1) & 1))
        to[S] |= to[S ^ (1 << i) ^ (1 << i + 1)];
  }
  dfs(1);
  f[1] = 1;
  while(m) {
    if(m & 1) {
      memset(g, 0, sizeof(g)), swap(f, g);
      for(re int i = 1; i <= T; ++i)
        for(re int j = 1; j <= T; ++j)
          addr(f[i], 1ll * g[j] * mat[j][i] % P);
    }
    memset(tmp, 0, sizeof(tmp)), swap(mat, tmp);
    for(re int i = 1; i <= T; ++i)
      for(re int j = 1; j <= T; ++j)
        for(re int k = 1; k <= T; ++k)
          addr(mat[i][j], 1ll * tmp[i][k] * tmp[k][j] % P);
    m >>= 1;
  }
  int ans = 0;
  for(re int i = 1; i <= T; ++i)
    if(rev[i] & 1) addr(ans, f[i]);
  cout << ans;
}