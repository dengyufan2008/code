#include<bits/stdc++.h>
#define il inline
#define re register
#define ll long long
#define pii pair<int, int>
#define fi first
#define se second
#define eb emplace_back
using namespace std;
#define N 55
int n, m, a[N], b[N], s[N], t[N], p[N][N];
struct node {int x, y, nx, ny;} ; vector<node> ans;
il void move(int i, int dx, int dy) {
  int x = a[i], y = b[i], nx = x + dx, ny = y + dy;
  ans.eb(node {x, y, nx, ny}), p[x][y] = 0, p[nx][ny] = i, a[i] = nx, b[i] = ny;
}
il bool lef(int x, int y) {
  if(!p[x][y]) return 1;
  if(y > 1 && lef(x, y - 1)) {move(p[x][y], 0, -1); return 1;}
  return 0;
}
il bool rig(int x, int y) {
  if(!p[x][y]) return 1;
  if(y < n && rig(x, y + 1)) {move(p[x][y], 0, 1); return 1;}
  return 0;
}
il bool up(int x, int y) {
  if(!p[x][y]) return 1;
  if(x > 1 && up(x - 1, y)) {move(p[x][y], -1, 0); return 1;}
  return 0;
}
il bool down(int x, int y) {
  if(!p[x][y]) return 1;
  if(x < n && down(x + 1, y)) {move(p[x][y], 1, 0); return 1;}
  return 0;
}
bool use[N];
mt19937 rnd(114514);
il void work(int i, int op) {
  if(op == 0) {
    while(a[i] > s[i] && !use[p[a[i] - 1][b[i]]])
      lef(a[i] - 1, b[i]), rig(a[i] - 1, b[i]), move(i, -1, 0);
    while(a[i] < s[i] && !use[p[a[i] + 1][b[i]]])
      lef(a[i] + 1, b[i]), rig(a[i] + 1, b[i]), move(i, 1, 0);
  }
  else {
    while(b[i] > t[i] && !use[p[a[i]][b[i] - 1]])
      up(a[i], b[i] - 1), down(a[i], b[i] - 1), move(i, 0, -1);
    while(b[i] < t[i] && !use[p[a[i]][b[i] + 1]])
      up(a[i], b[i] + 1), down(a[i], b[i] + 1), move(i, 0, 1);
  }
}
il void solve(int i) {
  if(rnd() & 1) work(i, 0), work(i, 1);
  else work(i, 1), work(i, 0);
}
il bool check() {
  for(re int i = 1; i <= n; ++i)
    if(a[i] != s[i] || b[i] != t[i]) return 0;
  return 1;
}
int main() {
  freopen("sheep.in", "r", stdin);
  freopen("sheep.out", "w", stdout);
  ios::sync_with_stdio(0);
  cin.tie(0), cout.tie(0);
  cin >> n >> m;
  for(re int i = 1; i <= m; ++i) cin >> a[i] >> b[i], p[a[i]][b[i]] = i;
  for(re int i = 1; i <= m; ++i) cin >> s[i] >> t[i];
  vector<int> p;
  for(re int i = 1; i <= m; ++i) p.eb(i);
  while(!check()) {
    shuffle(p.begin(), p.end(), rnd);
    for(re int i = 1; i <= n; ++i) use[i] = 0;
    for(auto x : p) solve(x), use[x] = 1;
  }
  cout << ans.size() << "\n";
  for(auto t : ans) cout << t.x << " " << t.y << " " << t.nx << " " << t.ny << "\n";
}