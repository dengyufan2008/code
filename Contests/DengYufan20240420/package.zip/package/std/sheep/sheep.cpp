#include<bits/stdc++.h>
#define il inline
#define re register
#define ll long long
#define pii pair<int, int>
#define fi first
#define se second
#define eb emplace_back
using namespace std;
#define N 55
#define M 1705
int n, m, Emp; pii ed[M];
struct node {int x, y, nx, ny;} ;
struct tmp {int x, y, id;} ;
struct game {
  tmp a[M]; pii b[M];
  int p[N][N]; vector<node> ans;
  il void move(int i, int dx, int dy) {
    int x = a[i].x, y = a[i].y, nx = x + dx, ny = y + dy;
    ans.eb(node {x, y, nx, ny}), p[x][y] = 0, p[nx][ny] = i, a[i] = tmp {nx, ny, a[i].id};
  }
  il bool check() {
    for(re int i = 1; i <= m; ++i)
      if(pii {a[i].x, a[i].y} != b[i]) return 0;
    return 1;
  }
  il void work(int i) {
    int x = a[i].x, y = a[i].y, ex = b[i].fi, ey = b[i].se;
    if(x == ex && y == ey) return ;
    if(x > ex) {
      while(x > ex && !p[x - 1][y]) move(i, -1, 0), --x;
      if(x != ex && p[x - 1][y]) {
        swap(b[i], b[p[x - 1][y]]); return ;
      }
    }
    if(x < ex) {
      while(x < ex && !p[x + 1][y]) move(i, 1, 0), ++x;
      if(x != ex && p[x + 1][y]) {
        swap(b[i], b[p[x + 1][y]]); return ;
      }
    }
    if(y > ey) {
      while(y > ey && !p[x][y - 1]) move(i, 0, -1), --y;
      if(y != ey && p[x][y - 1]) {
        swap(b[i], b[p[x][y - 1]]); return ;
      }
    }
    if(y < ey) {
      while(y < ey && !p[x][y + 1]) move(i, 0, 1), ++y;
      if(y != ey && p[x][y + 1]) {
        swap(b[i], b[p[x][y + 1]]); return ;
      }
    }
  }
  il void solve() {
    for(re int i = 1; i <= m; ++i) cin >> a[i].x >> a[i].y, a[i].id = i;
    sort(a + 1, a + 1 + m, [](tmp A, tmp B) {return pii {A.x, A.y} < pii {B.x, B.y};});
    for(re int i = 1; i <= m; ++i) p[a[i].x][a[i].y] = i, b[i] = ed[i];
    while(!check()) for(re int i = 1; i <= m; ++i) work(i);
  }
} S, T;
pii pos[M]; int rev[N][N];
vector<node> ans;
il void move(pii &f, int dx, int dy) {
  ans.eb(node {f.fi, f.se, f.fi + dx, f.se + dy}), f.fi += dx, f.se += dy;
}
il void moveEmp(pii &f) {
  if(f.fi % 3 == 2) move(f, -1, 0); else move(f, 1, 0);
  while(f.se < Emp) move(f, 0, 1); while(f.se > Emp) move(f, 0, -1);
}
il void moveX(pii &f, int x) {
  while(f.fi < x) move(f, 1, 0); while(f.fi > x) move(f, -1, 0);
}
il void moveY(pii &f, int y) {
  while(f.se < y) move(f, 0, 1); while(f.se > y) move(f, 0, -1);
}
il void exc(pii s, pii t) {
  if(s == t) return ;
  int x = s.fi, y = s.se, ex = t.fi, ey = t.se;
  swap(pos[rev[x][y]], pos[rev[ex][ey]]);
  swap(rev[x][y], rev[ex][ey]);
  moveEmp(s); int sx = s.fi;
  while(s.fi < n) move(s, 1, 0);
  moveEmp(t); int tx = t.fi;
  moveX(t, sx), moveY(t, y), moveX(t, x);
  moveX(s, tx), moveY(s, ey), moveX(s, ex);
}
int main() {
  freopen("sheep.in", "r", stdin);
  freopen("sheep.out", "w", stdout);
  ios::sync_with_stdio(0);
  cin.tie(0), cout.tie(0);
  cin >> n >> m;
  Emp = n + 1 >> 1; int C = 0;
  for(re int i = 1; i <= n; ++i) {
    if(i % 3 == 1 || (i % 3 == 0 && i == n)) continue;
    for(re int j = 1; j <= n; ++j) {
      if(j == Emp) continue;
      ed[++C] = pii {i, j};
    }
  }
  sort(ed + 1, ed + 1 + m);
  S.solve(), T.solve();
  for(re int i = 1; i <= m; ++i) {
    tmp t = S.a[i]; pos[t.id] = pii {t.x, t.y}, rev[t.x][t.y] = t.id;
  }
  for(re int i = 1; i <= m; ++i) exc(pos[T.a[i].id], pii {T.a[i].x, T.a[i].y});
  reverse(T.ans.begin(), T.ans.end()); for(auto &t : T.ans) swap(t.x, t.nx), swap(t.y, t.ny);
  vector<node> Fans;
  for(auto t : S.ans) Fans.eb(t);
  for(auto t : ans) Fans.eb(t);
  for(auto t : T.ans) Fans.eb(t);
  cout << Fans.size() << "\n";
  for(auto t : Fans) cout << t.x << " " << t.y << " " << t.nx << " " << t.ny << "\n";
}
