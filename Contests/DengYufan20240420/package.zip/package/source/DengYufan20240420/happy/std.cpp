#include <fstream>
#include <queue>
#define LL long long

using namespace std;

ifstream cin("happy.in");
ofstream cout("happy.out");

const int kMaxN = 1e7 + 1;
struct V {
  int f, c;
} v[kMaxN];
int n, m, k, a[kMaxN], b[kMaxN];
unsigned seed;
LL ans;
vector<int> c[kMaxN];

unsigned Rand() {
  seed ^= seed << 13;
  seed ^= seed >> 17;
  seed ^= seed << 5;
  return seed;
}

int GetRoot(int x) {
  return v[x].f == x ? x : v[x].f = GetRoot(v[x].f);
}

int main() {
  cin.tie(0), cout.tie(0);
  ios::sync_with_stdio(0);
  cin >> n >> m >> seed;
  for (int i = 1; i <= n; i++) {
    a[i] = 1, b[i] = Rand() % m + 1;
  }
  for (int i = 1; i <= n - 2; ++i) {
    a[Rand() % n + 1]++;
  }
  for (int i = 1; i <= n; i++) {
    c[b[i]].push_back(a[i]);
  }
  for (int i = m, p = 0; i >= 1; i--) {
    for (int j : c[i]) {
      p++, a[p] = j, b[p] = i;
    }
  }
  for (int i = 1; i <= n; i++) {
    v[i].f = i, v[i].c = 1;
  }
  for (int i = 1; i <= n; i++) {
    for (int j = i + 1; j <= n && a[i]; j++) {
      if (a[j] && GetRoot(i) != GetRoot(j)) {
        int w = v[GetRoot(i)].c - (a[i] == 1) + v[GetRoot(j)].c - (a[j] == 1);
        if (w || k == n - 2) {
          a[i]--, a[j]--, k++, ans += 1LL * b[i] * b[j];
          v[GetRoot(i)].c = w, v[GetRoot(j)].f = GetRoot(i);
        }
      }
    }
  }
  cout << ans << '\n';
  return 0;
}
