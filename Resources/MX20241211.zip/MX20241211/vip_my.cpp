#include <algorithm>
#include <fstream>
#include <queue>

using namespace std;

ifstream cin("vip.in");
ofstream cout("vip.out");

const int kMaxN = 31, kMaxM = 21, kMod = 998244353;
int n, m, a[kMaxN], b[kMaxN], ans[kMaxN];
priority_queue<int, vector<int>, greater<int>> q;

void S(int x) {
  if (x > n) {
    int w = 0, k = 0;
    for (int i = 1; i <= n; i++) {
      while (!q.empty() && w + q.top() <= b[i]) {
        w += q.top(), q.pop(), k++;
        ans[k] = (ans[k] + w) % kMod;
      }
      if (!q.empty()) {
        int x = q.top();
        q.pop(), q.push(x - b[i] + w);
      }
      w = b[i], q.push(a[i]);
    }
    while (!q.empty()) {
      w += q.top(), q.pop(), k++;
      ans[k] = (ans[k] + w) % kMod;
    }
    return;
  }
  for (int i = 1; i <= m; i++) {
    a[x] = i, S(x + 1);
  }
}

int main() {
  cin.tie(0), cout.tie(0);
  ios::sync_with_stdio(0);
  cin >> n >> m;
  for (int i = 1; i <= n; i++) {
    cin >> b[i];
  }
  sort(b + 1, b + n + 1), S(1);
  for (int i = 1; i <= n; i++) {
    cout << ans[i] << " \n"[i == n];
  }
  return 0;
}
