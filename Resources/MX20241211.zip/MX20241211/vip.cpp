/*
Things to notice:
1. do not calculate useless values
2. do not use similar names

Things to check:
1. submit the correct file
2. time (it is log^2 or log)
3. memory
4. prove your naive thoughts
5. long long
6. corner case like n=0,1,inf or n=m
7. check if there is a mistake in the ds or other tools you use
8. fileio in some oi-contest

9. module on time
10. the number of a same divisor in a math problem
11. multi-information and queries for dp and ds problems
*/
#include <bits/stdc++.h>
using namespace std;
#define int long long
#define fi first
#define se second
#define pii pair<long long, long long>
#define mp make_pair
#define pb push_back
const int mod = 998244353;
const int inf = 0x3f3f3f3f;
const int INF = 1e18;
int fpow(int x, int b) {
  if (b == 0) return 1;
  if (x == 0) return 0;
  int res = 1;
  while (b > 0) {
    if (b & 1) res = 1LL * res * x % mod;
    x = 1LL * x * x % mod;
    b >>= 1;
  }
  return res;
}
void add(int &x, int y) {
  x += y;
  if (x >= mod) x -= mod;
}
int ans[31];
int n, V, b[33];
int dp[2][31][23][23][1201];
void solve() {
  cin >> n >> V;
  for (int i = 1; i <= n; i++) cin >> b[i];
  sort(b + 1, b + 1 + n);
  dp[0][0][0][V + 1][0] = 1;
  int nw = 0;
  b[n + 1] = inf;
  for (int i = 1; i <= n + 1; i++) {
    nw ^= 1;
    memset(dp[nw], 0, sizeof(dp[nw]));
    int coef2 = fpow(V, n - i + 1);
    for (int k = 0; k < i; k++)
      for (int L = 0; L <= V; L++)
        for (int R = L; R <= V + 1; R++)
          for (int s = 0; s <= 1200; s++)
            if (dp[nw ^ 1][k][L][R][s]) {
              int x = dp[nw ^ 1][k][L][R][s];
              if (L && s <= b[i]) add(ans[k], 1LL * coef2 * x % mod * s % mod);
            }
    if (i == n + 1) continue;
    for (int k = 0; k < i; k++)
      for (int L = 0; L <= V; L++)
        for (int R = L; R <= V + 1; R++)
          for (int s = 0; s <= 1200; s++)
            if (dp[nw ^ 1][k][L][R][s]) {
              //			cerr<<k<<" "<<L<<" "<<R<<" "<<s<<"\n";
              if (R <= V && s + R <= b[i]) continue;
              int x = dp[nw ^ 1][k][L][R][s];
              int LL, RR, ss;
              if (s <= b[i]) {
                ss = b[i];
                LL = 0;
              } else {
                ss = s;
                LL = min(L, s - b[i]);
              }
              if (R == V + 1)
                RR = V + 1;
              else
                RR = R - ss + s;
              //			cerr<<LL<<" "<<RR<<" "<<ss<<"\n";
              for (int u = 1; u <= V; u++) {
                if (u < LL)
                  add(dp[nw][k + 1][LL][RR][ss + u], x);
                else if (u < RR)
                  add(dp[nw][k][LL][u][ss], x), add(dp[nw][k + 1][u][RR][ss + u], x);
                else
                  add(dp[nw][k][LL][RR][ss], x);
              }
              //			cerr<<"...\n";
            }
  }
  for (int i = 1; i <= n; i++) cout << ans[i] << " ";
}
signed main() {
  //	ios::sync_with_stdio(0);
  //	cin.tie(0);
  int _ = 1;
  //	cin>>_;
  while (_--) solve();
  return 0;
}
