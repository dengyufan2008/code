#include <fstream>
#include <vector>
#define LL long long

using namespace std;

ifstream cin("collect.in");
ofstream cout("collect.out");

const LL kMaxN = 3e5 + 1, kMaxM = 1e6 + 1, kInf = 1e18;
struct Graph {
  struct E {
    int x, y, z;
  } e[kMaxM];
  int n, m;
} g;
int o;

class Union {
  int f[kMaxN], s[kMaxN];
  LL w[kMaxN];

 public:
  void Init(int n) {
    for (int i = 1; i <= n; i++) {
      f[i] = i, s[i] = 1, w[i] = 0;
    }
  }

  int GetRoot(int x) { return f[x] == x ? x : f[x] = GetRoot(f[x]); }

  bool IsRoot(int x) { return f[x] == x; }

  int Size(int x) { return s[x]; }

  LL Ask(int x) { return w[x]; }

  void Merge(int x, int y, int z) {
    x = GetRoot(x), y = GetRoot(y);
    if (x == y) {
      w[x] += z;
    } else {
      s[x] < s[y] ? swap(x, y) : void();
      f[y] = x, s[x] += s[y], w[x] += w[y] + z;
    }
  }
};

vector<LL> &Construct(Graph &g) {
  static int u;
  static LL mn;
  static vector<LL> ans;
  static Union h;
  h.Init(g.n);
  for (int i = 1; i <= g.m; i++) {
    h.Merge(g.e[i].x, g.e[i].y, g.e[i].z);
  }
  mn = kInf;
  for (int i = 1; i <= g.n; i++) {
    if (h.IsRoot(i) && mn > h.Ask(i)) {
      mn = h.Ask(i), u = i;
    }
  }
  ans.assign(g.n + 1, 0);
  for (int i = 1; i <= g.m; i++) {
    if (h.GetRoot(g.e[i].x) == u) {
      ans[g.e[i].x] += g.e[i].z;
    }
  }
  return ans;
}

/// @return 0:valid 1:too small 2:too big 3:not free
int Check(Graph &g, vector<LL> &w, bool minimize) {
  static int c[kMaxN];
  static LL ans, s[kMaxN];
  static bool b[kMaxN];
  static vector<int> v;
  static vector<pair<int, int>> e[kMaxN];
  static Union h;

  h.Init(g.n);
  for (int i = 1; i <= g.m; i++) {
    h.Merge(g.e[i].x, g.e[i].y, g.e[i].z);
  }
  ans = kInf;
  for (int i = 1; i <= g.n; i++) {
    if (h.IsRoot(i)) {
      ans = min(ans, h.Ask(i));
    }
  }

  if (!ans) {
    return 0;
  } else if (minimize) {
    LL ww = 0;
    for (int i = 1; i <= g.n; i++) {
      ww += w[i];
    }
    if (ww < ans) {
      return 1;
    } else if (ww > ans) {
      return 2;
    }
  }

  for (int i = 1; i <= g.n; i++) {
    s[i] = 0, e[i].clear();
  }
  for (int i = 1; i <= g.m; i++) {
    int x = g.e[i].x, y = g.e[i].y, z = g.e[i].z;
    s[x] += z, s[y] += z;
    e[x].push_back({y, z}), e[y].push_back({x, z});
  }

  v.clear();
  for (int i = 1; i <= g.n; i++) {
    if (w[i] >= s[i]) {
      b[i] = 1, v.push_back(i);
    } else {
      b[i] = 0;
    }
  }
  for (; !v.empty();) {
    int x = v.back();
    v.pop_back();
    for (auto i : e[x]) {
      if (!b[i.first]) {
        s[i.first] -= i.second;
        if (w[i.first] >= s[i.first]) {
          b[i.first] = 1, v.push_back(i.first);
        }
      }
    }
  }

  for (int i = 1; i <= g.n; i++) {
    c[i] = 0;
  }
  for (int i = 1; i <= g.n; i++) {
    c[h.GetRoot(i)] += b[i];
  }
  for (int i = 1; i <= g.n; i++) {
    if (h.IsRoot(i) && c[i] == h.Size(i)) {
      return 0;
    }
  }
  return 3;
}

int main() {
  cin.tie(0), cout.tie(0);
  ios::sync_with_stdio(0);
  cin >> o >> g.n >> g.m;
  for (int i = 1; i <= g.m; i++) {
    cin >> g.e[i].x >> g.e[i].y >> g.e[i].z;
  }
  if (o == 1) {
    vector<LL> &ans = Construct(g);
    for (int i = 1; i <= g.n; i++) {
      cout << ans[i] << " \n"[i == g.n];
    }
  } else {
    static vector<LL> w;
    w.resize(g.n + 1);
    for (int i = 1; i <= g.n; i++) {
      cin >> w[i];
    }
    cout << (!Check(g, w, 0) ? "YES\n" : "NO\n");
  }
  return 0;
}
