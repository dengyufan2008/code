#include<bits/stdc++.h>
using namespace std;
#define pi pair<int,int>
#define vec vector<int>
#define pb push_back
#define int long long
#define M 998244353
void in(int &x){
    int f=1;x=0;
    char c=getchar();
    while(!isdigit(c)&&c!='-')c=getchar();
    if(c=='-')f=-1,c=getchar();
    while(isdigit(c))x=x*10+c-'0',c=getchar();
    x*=f;
}
mt19937 rnd(19260817);
int t,n,m,k,fl,x,y,p,D=30,lim=(1<<D)-1,K=30;
char S[2][105][105];
void clear(vec &a){while(!a.empty()&&!a.back())a.pop_back();}
struct Big:public vec{using vec::vector;}half,A[35][105][105],B[35][105][105],res[35];
int d[100005],e;
void print(Big res,int l=p){
	e=0;if(res.empty()){printf("0");return;}
	for(int i=0;i<res.size();i++)for(int j=D-1;j>=0;j--)d[++e]=(res[i]>>j)&1;
	while(e<l)d[++e]=0;
    int ans=0;
    for(int i=1;i<=l;i++)ans=(ans*2+d[i])%M;
    printf("%lld",ans);
}
Big operator +(const Big &a,const Big &b){
	Big res(max(a.size(),b.size()));
	for(int i =(int)res.size()-1;i>=0;i--){
		if(i<a.size())res[i]+=a[i];
		if(i<b.size())res[i]+=b[i];
		if(res[i]>lim){res[i]&=lim;if(i)res[i-1]++;}
	}
	clear(res);return res;
}
Big operator -(Big a){
	if(a.empty())return a;
	a.back()=(-a.back())&lim;
	for(int i=0;i<(int)a.size()-1;i++)a[i]^=lim;
	return a;
}
Big operator -(const Big &a,const Big &b){return a+(-b);}
Big operator *(const Big &a,const Big &b){
	if(a.empty()||b.empty())return{};
	Big res(a.size()+b.size()+1);
	for(int i=0;i<a.size();i++)for(int j=0;j<b.size();j++)res[i+j+1]+=a[i]*b[j];
	for(int i=(int)res.size()-1;i>=0;i--){
		if(i)res[i-1]+=(res[i]>>D);
		res[i]&=lim;
	}
	clear(res);return res;
}
int len(const Big &a){return a.empty()?0:D*a.size()-__builtin_ctzll(a.back());}
Big operator <<(const Big &a,int k){
	int b=k/D,d=k%D;
	Big res(a.size());
	if(b<a.size())res[0]=a[b]<<d&lim;
	for(int i=b+1;i<a.size();i++){
		res[i-b]|=a[i]<<d&lim;
		res[i-b-1]|=a[i]>>D-d;
	}
	clear(res);return res;
}
Big operator >>(const Big &a,int k){
	int b=k/D,d=k%D;
	Big res(a.size()+b+1);
	for(int i=0;i<a.size();i++){
		res[i+b]|=a[i]>>d;
		res[i+b+1]|=(a[i]<<D-d)&lim;
	}
	clear(res);return res;
}
Big inv(Big a){
	Big res=a;int b=len(a);
	for(int i=0;i<b-2;i++){
		a=a*a<<b;
		res=res*a<<b;
	}
	clear(res);return res;
}
void work(int id){
	for(int i=1;i<=n;i++){S[0][i][m+1]='0';B[id][i][m+1].clear();if(rnd()&1)B[id][i][m+1]=half;}
	for(int i=1;i<=m;i++){S[0][n+1][i]='0';B[id][n+1][i].clear();if(rnd()&1)B[id][n+1][i]=half;}
	for(int i=n;i>=1;i--){
		for(int j=m;j>=1;j--){
			if(S[0][i][j]=='0'){
				B[id][i][j].clear();
				if(rnd()&1)B[id][i][j]=half;
			}
			else{
				Big x=(S[0][i][j+1]=='0'?B[id][i][j+1]:B[id][i][j+1]>>1);
				Big y=(S[0][i+1][j]=='0'?B[id][i+1][j]:B[id][i+1][j]>>1);
				B[id][i][j]=x+y;A[id][i][j]=x-y;
			}
		}
	}
}
void solve(){
	bool fl=1;
	for(int i=1;i<K;i++)fl&=(res[i]==res[0]);
	if(!fl)puts("-1");
    else print(min(-res[0],res[0])),puts("");
}
signed main(){
	freopen("dis.in", "r", stdin);
	freopen("dis.out", "w", stdout);
	in(n);in(m);in(t);half.pb(1<<D-1);
	for(int o=0;o<=1;o++)for(int i=1;i<=n;i++)scanf("%s",S[o][i]+1);
	for(int i=0;i<K;i++)work(i),p=max(p,len(B[i][1][1]));
	for(int o=0;o<K;o++){
		while(len(B[o][1][1])<p)work(o);
		Big iv=inv(B[o][1][1]);
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				A[o][i][j]=A[o][i][j]*iv<<p;
				if(S[0][i][j]=='1')res[o]=res[o]-A[o][i][j];
				if(S[1][i][j]=='1')res[o]=res[o]+A[o][i][j];
			}
		}
	}
	solve();
	while(t--){
		in(fl);in(x);in(y);
		for(int i=0;i<K;i++){
			if(fl==1){
				if(S[0][x][y]=='1')res[i]=res[i]+A[i][x][y];
				if(S[0][x][y]=='2')res[i]=res[i]-A[i][x][y];
			}
			else{
				if(S[1][x][y]=='1')res[i]=res[i]-A[i][x][y];
				if(S[1][x][y]=='2')res[i]=res[i]+A[i][x][y];
			}
		}
		if(fl==1){if(S[0][x][y]!='0')S[0][x][y]^='1'^'2';}
		else {if(S[1][x][y]!='0')S[1][x][y]^='1'^'2';}
		solve();
	}
}