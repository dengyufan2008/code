#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <random>
#include <ctime>
#include <unordered_map>
#define ll unsigned long long
using namespace std;

int m,q,tme;
char c[1000005];
int opt[1000005];
int lim[1000005];
int dfn[2000005];
ll hs[2000005];
ll val[1000005];
unordered_map <ll,ll> Mp;
mt19937_64 rnd(time(NULL));

inline void in(int &n){
	n=0;
	char c=getchar();
	while(c<'0' || c>'9') c=getchar();
	while(c>='0'&&c<='9') n=n*10+c-'0',c=getchar();
	return ;
}

int tot=1;
int fa[2000005];
int siz[2000005];
int len[2000005];
int enp[2000005];
int mp[2000005][26];
vector <int> g[2000005];

inline int ins(int c,int las){
	if(mp[las][c]){
		int p=las,v=mp[p][c];
		if(len[p]+1==len[v]) return v;
		int x=++tot;
		len[x]=len[p]+1;
		for(int i=0;i<26;i++) mp[x][i]=mp[v][i];
		while(mp[p][c]==v) mp[p][c]=x,p=fa[p];
		fa[x]=fa[v],fa[v]=x;
		return x;
	}
	int x=++tot,p=las;
	len[x]=len[p]+1;
	while(p&&!mp[p][c]) mp[p][c]=x,p=fa[p];
	if(!p) fa[x]=1;
	else{
		int v=mp[p][c];
		if(len[p]+1==len[v]) fa[x]=v;
		else{
			int y=++tot;
			len[y]=len[p]+1;
			for(int i=0;i<26;i++) mp[y][i]=mp[v][i];
			while(mp[p][c]==v) mp[p][c]=y,p=fa[p];
			fa[y]=fa[v],fa[x]=fa[v]=y;
		}
	}
	return x;
}

int Tot;
int rt[2000005];
int sz[32000005];
int lc[32000005];
int rc[32000005];
vector <int> glim[2000005];

inline void ins(int &u,int l,int r,int k){
	if(!u) u=++Tot;
	if(l==r){sz[u]++;return ;}
	int mid=(l+r)>>1;
	if(k<=mid) ins(lc[u],l,mid,k);
	else ins(rc[u],mid+1,r,k);
	return ;
}

inline int merge(int p,int q,int l,int r,int U){
	if(!p||!q) return p|q;
	if(l==r){
		sz[p]+=sz[q];
		if(sz[p]<-1e9) sz[p]=-1e9;
		if(sz[p]>=lim[l]){
			sz[p]=-1e9;
			glim[U].emplace_back(l);
		}
		return p;
	}
	int mid=(l+r)>>1;
	lc[p]=merge(lc[p],lc[q],l,mid,U);
	rc[p]=merge(rc[p],rc[q],mid+1,r,U);
	return p;
}

int lst[2000005];
vector <int> gv[2000005];
vector <int> gp[2000005];
ll T[2000005];
inline void add(int x,ll k){while(x<=tme) T[x]^=k,x+=x&-x;return ;}
inline ll ask(int x){ll s=0;while(x) s^=T[x],x^=x&-x;return s;}

inline void init(int u){
	dfn[u]=++tme;
	for(int v:g[u]) init(v);
	for(int v:g[u]){
		if(!enp[u]) enp[u]=enp[v];
		else if(enp[v]&&enp[v]<enp[u]) enp[u]=enp[v];
		rt[u]=merge(rt[u],rt[v],1,m,u);
		siz[u]+=siz[v];
	}
	for(int v:glim[u]) gv[dfn[u]].emplace_back(v);
	gp[tme].emplace_back(u);
	return ;
}

inline void dfs(int u){
	if(!enp[u]) return ;
	if(u!=1) Mp[hs[u]]+=1ll*(len[u]-len[fa[u]])*siz[u];
	for(int v:g[u]) dfs(v);
	return ;
}

int main(){
	freopen("music.in","r",stdin);
	freopen("music.out","w",stdout);
	in(m),in(q);
	scanf("%s",c+1);
	int len=strlen(c+1),las=1;
	for(int i=1;i<=len;i++) las=ins(c[i]-'a',las),enp[las]=i,siz[las]++;
	for(int i=1;i<=m;i++) in(opt[i]);
	for(int i=1;i<=m;i++) in(lim[i]);
	ll SS=0;
	for(int i=1;i<=m;i++){
		val[i]=rnd();
		if(opt[i]) SS^=val[i];
		scanf("%s",c+1);
		len=strlen(c+1),las=1;
		for(int j=1;j<=len;j++){
			las=ins(c[j]-'a',las);
			ins(rt[las],1,m,i);
			if(lim[i]==1) glim[las].emplace_back(i);
		}
	}
	for(int i=2;i<=tot;i++) g[fa[i]].emplace_back(i);
	init(1);
	for(int i=1;i<=tme;i++){
		for(ll v:gv[i]){
			if(lst[v]) add(lst[v],val[v]);
			add(i,val[v]);
			lst[v]=i;
		}
		for(int v:gp[i]) hs[v]^=SS^ask(i)^ask(dfn[v]-1);
	}
	dfs(1);
	for(int i=1;i<=m;i++) val[i]^=val[i-1];
	ll all=val[m];
	while(q--){
		int l,r;
		in(l),in(r);
		all^=val[r]^val[l-1];
		printf("%llu\n",Mp[all]);
	}

	return 0;
}