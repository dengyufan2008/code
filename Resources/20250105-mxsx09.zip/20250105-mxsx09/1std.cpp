#include <bits/stdc++.h>
using namespace std;
#define PII pair<int,int>
#define x first
#define y second
#define For(i, l, r) for(int i = l; i <= r; i ++)
const int N = 5e5 + 50;
int n, m, a[N], p[N], Ans[N], c[N]; vector<PII> vec[N], qr[N];
void upd(int x) {int y = 1; if(x < 0) y = -1, x = -x;  while(x <= n) c[x] += y, x += x & (-x);}
int qsum(int x) {int s = 0; while(x > 0) s += c[x], x -= x & (-x); return s;}
int main()
{
	freopen("divide.in", "r", stdin);
	freopen("divide.out", "w", stdout);
	set<int> hav, se; scanf("%d%d", &n, &m); For(i, 1, n) scanf("%d", a + i) , p[a[i]] = i;
	For(i, 0, n + 1) se.insert(i); hav.insert(n + 1); hav.insert(0);
	For(ii, 1, n - 1)
	{
		int x = p[ii], z; int y = *se.upper_bound(x); int l = *prev(se.lower_bound(x)) + 1;
		if(y <= n){z = *hav.upper_bound(y) - 1; vec[l].push_back({y, -z-1}); vec[x + 1].push_back({-y, z+1});}
		se.erase(x); hav.insert(x);
	}
	For(i, 1, m) {int l, r; scanf("%d%d", &l, &r); qr[l].push_back({r, i});}
	For(i, 1, n) {for(PII E : vec[i]) upd(E.x), upd(E.y); for(PII E : qr[i]) Ans[E.y] = qsum(E.x);}
	For(i, 1, m) printf("%d\n", Ans[i]);
	return 0;
}